package com.example.fragmentcolorlabels;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void buttonClick(View view){
        TextView redLabel = findViewById(R.id.red_label);
        TextView greenLabel = findViewById(R.id.green_label);
        TextView blueLabel = findViewById(R.id.blue_label);

        count++;
        if(count == 1){
            redLabel.setVisibility(View.INVISIBLE);
            greenLabel.setVisibility(View.VISIBLE);
        }
        if(count == 2) {
            greenLabel.setVisibility(View.INVISIBLE);
            blueLabel.setVisibility(View.VISIBLE);

        }

    }

}