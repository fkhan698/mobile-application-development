package com.example.exercise3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class second_activity extends AppCompatActivity {
    int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_activity);

        Intent activityThatCalled = getIntent();
        String previousActivity = activityThatCalled.getExtras().getString("callingActivity");


    }
    public void onSendCountClick(View view){

        Intent goingBack = new Intent();
        count++;
        String countNumber = String.valueOf(count);
        goingBack.putExtra("buttonCount", countNumber);
        setResult(RESULT_OK, goingBack);
        finish();
    }
}

