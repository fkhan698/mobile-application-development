package com.example.exercise2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void changeColor(View view){
        count ++;
        TextView label = findViewById(R.id.color_label);
//        if(count == 0){
//            label.setBackgroundColor(Color.RED);
//            label.setText("RED");
//        }
        if(count == 1 ){
            label.setBackgroundColor(Color.YELLOW);
            label.setText("Yellow");
            label.setTextColor(Color.BLACK);
        }
        if(count == 2){
            label.setBackgroundColor(Color.GREEN);
            label.setText("Green");
            count = 0;
        }

    }

}